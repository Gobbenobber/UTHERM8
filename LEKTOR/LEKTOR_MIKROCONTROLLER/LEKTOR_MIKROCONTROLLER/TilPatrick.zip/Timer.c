/*
 * Timer.c
 *
 * Created: 22-05-2017 10:50:20
 *  Author: Kasper
 */ 
