/*
 * ToggleSwitchLED.c
 *
 * Created: 22-05-2017 10:50:52
 *  Author: Kasper
 */ 
