/*
 * RegistrerLektor_PaaKontor.c
 *
 * Created: 22-05-2017 10:49:42
 *  Author: Kasper
 */ 
