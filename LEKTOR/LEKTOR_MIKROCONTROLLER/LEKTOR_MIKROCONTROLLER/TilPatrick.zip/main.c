#include <avr/io.h>
#include <avr/interrupt.h>
#define F_CPU 16000000
#include <util/delay.h>

// Prototyper
void initExtInts(int interruptnr);

#define DDR   DDRB
#define PORT PORTB
#define PINNR 0
#define BAUD  9600

#define NO_us 80000/BAUD

//--------------------------------------
volatile static int outputShizzle = 1;
/*
void initExtInt(int interruptnr)
{
	// INT2:Rising edge
	if (interruptnr==0)
	{
		EICRA=0b00000011;
		EIMSK |= 0b00000001;
	}
	
	else if(interruptnr==1)
	{
		EICRA=0b00001100;
		EIMSK |= 0b00000010;
	}
	
	else if (interruptnr==2)
	{
		EICRA=0b00110000;
		EIMSK |= 0b00000100;
	}
	
	else if(interruptnr==3)
	{
		EICRA=0b11000000;
		EIMSK |= 0b00001000;
	}
	
}
*/

// 8 data bit, no parity, 1 stop bit
void SendCharSW(char Tegn)
{
	// Main-loop: Toggle LED7 hvert sekund
	unsigned char i;
	unsigned char x = Tegn;
	// Start bit
	PORT &= ~(1<<PINNR);
	_delay_us(NO_us);
	// 8 data bits (LSB first)
	for (i = 0; i<8; i++)
	{
		if(x & 0b00000001)
		PORT |= (1<<PINNR);
		else
		PORT &= ~(1<<PINNR);
		_delay_us(NO_us);
		x = x>>1;
	}
	PORT |= (1<<PINNR);
	_delay_us(NO_us);
	PORT &= ~(1<<PINNR);
}

int main(void)
{
	////////////////////////////////////////////////////////////////
	///////TEST FOR EXTERNAL INTERRUPT, skal muligvis �ndres////////
	////////////////////////////////////////////////////////////////
	DDRD &= ~(1 << DDD2);     // Clear the PD2 pin (Nr. 2)
	// PD2 (PCINT0 pin) is now an input

	PORTD |= (1 << PORTD2);    // turn On the Pull-up
	// PD2 is now an input with pull-up enabled

	EICRA |= (1 << ISC11) | (1 << ISC10);   // set INT0 to trigger on ANY logic change
	EIMSK |= (1 << INT0);     // Turns on INT0
	////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////

	//UCSR0B = 0;
	DDR |= (1<<PINNR);

	// Global interrupt enable
	sei();

	while(1)
	{
	}
}

// Interrupt service routine for INT0 (Er INT3 for Atmega 2560)
ISR (INT0_vect)
{
	SendCharSW('a');





































































































































































































}