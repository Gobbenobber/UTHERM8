///////////////////////////////////////////////////////////////
///							- Sensor -						///
///				 Af Susanne, Patrick og Kasper				///
///		Denne klasse har til opgave at lave en timer		///
///////////////////////////////////////////////////////////////

#ifndef TIMER_H_
#define TIMER_H_

//Variables
volatile int ctr_ = 0;

//Functions
int returnerTimerStatus(char);

#endif /* TIMER_H_ */