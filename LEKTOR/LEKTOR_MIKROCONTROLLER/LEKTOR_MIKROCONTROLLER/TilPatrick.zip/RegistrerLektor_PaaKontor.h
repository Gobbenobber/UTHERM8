///////////////////////////////////////////////////////////////
///				- RegistrerLektor_PaaKontor -				///
///				 Af Susanne, Patrick og Kasper				///
///		Denne klasse har til opgave at s�tte lektors-		///
///		status til paa Kontor								///
///////////////////////////////////////////////////////////////

#ifndef REGISTRERLEKTOR_PAAKONTOR_H_
#define REGISTRERLEKTOR_PAAKONTOR_H_

//Functions
void skiftLEDTilstand_PaaKontor(char);
void lektorStatus_PaaKontor(char*);

#endif /* REGISTRERLEKTOR_PAAKONTOR_H_ */