/*
 * Sensor.c
 *
 * Created: 22-05-2017 10:50:05
 *  Author: Kasper
 */ 
